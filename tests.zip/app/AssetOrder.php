<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetOrder extends Model
{
    protected $table='asset_order';
    protected $primaryKey='id';
}
