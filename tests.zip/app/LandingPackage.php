<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LandingPackage extends Model
{
    protected $table='packages';
    protected $primaryKey='id_package';
}
