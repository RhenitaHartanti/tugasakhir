<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Google_Client;
use Google_Service_Calendar;
use Google_Service_Calendar_Event;

class oauthController extends Controller
{
    //
    protected $client;

    // public function __construct()
    // {
    //     $client = new Google_Client();
    //     $client->setAuthConfig('client_secret.json');
    //     $client->addScope(Google_Service_Calendar::CALENDAR);
    //     $guzzleClient = new \GuzzleHttp\Client(array('curl' => array(CURLOPT_SSL_VERIFYPEER => false)));
    //     $client->setHttpClient($guzzleClient);
    //     $this->client = $client;
    // }

    public function oauth()
    {
    //     session_start();
    //     $rurl = action('oauthController@oauth');
    //     $this->client->setRedirectUri($rurl);
    //     if (!isset($_GET['code'])) {
    //         $auth_url = $this->client->createAuthUrl();
    //         $filtered_url = filter_var($auth_url, FILTER_SANITIZE_URL);
    //         return redirect($filtered_url);
    //     } else {
    //         $this->client->authenticate($_GET['code']);
    //         $_SESSION['access_token'] = $this->client->getAccessToken();
    //         return redirect('admin_dashboard');
    //     }
    }
}
