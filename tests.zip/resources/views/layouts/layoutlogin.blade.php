<head>
 <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>PPP | Login Form</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="{{('dashboard/bower_components/bootstrap/dist/css/bootstrap.min.css')}}">
 
  <link rel="stylesheet" href="{{('dashboard/bower_components/Ionicons/css/ionicons.min.css')}}">
 
  <link rel="stylesheet" href="{{('dashboard/dist/css/AdminLTE.min.css')}}">

  </head>

 @yield('content')


  <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/agency.min.js"></script>
    <script src="{{('dashboard/bower_components/jquery/dist/jquery.min.js')}}"></script>
    <script src="{{('dashboard/bower_components/bootstrap/dist/js/bootstrap.min.js')}}"></script>

    <script src="{{('dashboard/plugins/iCheck/icheck.min.js')}}"></script>
  </body>

</html>