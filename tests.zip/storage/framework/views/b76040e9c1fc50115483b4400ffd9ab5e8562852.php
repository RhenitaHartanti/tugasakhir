<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <section class="order">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Order</h2>
        </div>
    <br>
    <table class="table table-striped text-center" style="color:#000000"> 
        <tr>
          <th>ID Order</th>
          <th>Date Order</th>
          <th>Name Package</th>
         <!--  <th>Start Date</th>
          <th>Finish Date</th>    -->      
          <th>Detail Order</th>
          <th>Order Status</th>   
          <th>Total Payment</th>    
          <th>Payment Process</th> 
          <th>Payment Status</th>
        </tr>
         <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
         <?php
                $pnjg = strlen($value->id);
                if($pnjg==1){
                  $id = 'ORD00'.$value->id;
                }elseif($pnjg==2){
                  $id = 'ORD0'.$value->id;
                }else{
                  $id = 'ORD'.$value->id;
                }
                ?>    
        <tr>
          <td><?php echo e($id); ?></td>
          <td><?php echo e($value->created_at); ?></td>          
          <td><?php echo e($value->package->name_package); ?></td>
          <!-- <td><?php echo e($value->date_using); ?></td>
          <td><?php echo e($value->date_finish); ?></td>  -->       
          <td><button onclick="detailOrder(this)" data-name_package="<?php echo e($value->package->name_package); ?>" data-date_using="<?php echo e($value->date_using); ?>" data-date_finish="<?php echo e($value->date_finish); ?>" data-theme="<?php echo e($value->theme); ?>" data-place="<?php echo e($value->place); ?>" data-guest="<?php echo e($value->package->kuota+$value->total_guests); ?>" data-greeting="<?php echo e($value->greeting); ?>" data-note="<?php echo e($value->note); ?>" data-total_payment="<?php echo e($value->total_payment); ?>" data-list="<?php echo e($value->package->assets->implode('name_asset',', ')); ?>"class="btn btn-sm btn-primary">See Detail Order</button></td>
          <td><b><?php echo e($value->order_status); ?></b></td>
          <td>Rp . <?php echo e($value->total_payment); ?></td>
          <td>
            <?php if($value->order_status!='accept'): ?>
            -
            <?php else: ?>
            <button class="btn btn-sm btn-primary"><a href="<?php echo e(URL::to('landingpage_formbayar/'.$value->id)); ?>" style="color:#ffffff;">confirm</a></button></td>
            <?php endif; ?>
          <td><b><?php echo e($value->payment_status); ?></b></td>     
        </tr>   
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </table>
    </div>   
</section>   
      <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <div id="modal-lihat" class="modal fade bs-example-modal-md" tabindex="-1" role="dialog" aria-hidden="true">
       <div class="modal-dialog modal-md">
        <div class="modal-content">
         <img src="img/logo6.jpg" alt="">
          <br>
           <form class="form-horizontal" method="POST" action="">
            <div class="box-body">
             <div class="form-group">
              <label for="date_using" class="col-md-12 control-label">Name Package : </label>
               <div class="col-sm-12 detail-name_package">            
                <input type="text" readonly disabled class="form-control" id="name_package" name="name_package" value="<?php echo e($value->name_package); ?>">                  
                </div>
                </div>
              <div class="form-group">
                label for="date_using" class="col-md-12 control-label">Date Using : </label>
                <div class="col-sm-12 detail-theme">            
                <input type="text" readonly disabled class="form-control" id="date_using" name="date_using" value="<?php echo e($value->date_using); ?>">                  
                </div>
              </div>
              <div class="form-group">
               <label for="time_using" class="col-md-12 control-label">Date Finish : </label>
                <div class="col-sm-12 date_finish">            
                  <input type="text" readonly disabled class="form-control" id="date_finish" name="date_finish" value="<?php echo e($value->date_finish); ?>">                  
                </div>
              </div>
              <div class="form-group">
                <label for="theme" class="col-md-12 control-label">Theme (Custom theme or character) : </label>
                <div class="col-sm-12 detail-theme">            
                 <input type="text" readonly disabled class="form-control" id="theme" name="theme" value="<?php echo e($value->theme); ?>">
                </div>
              </div>
              <div class="form-group">
               <label for="place" class="col-md-12 control-label">Place (include the complete address) : </label>
                <div class="col-sm-12 detail-place">                  
                 <input type="text" readonly disabled class="form-control" id="place" name="place" value="<?php echo e($value->place); ?>">
                </div>
              </div>
              <div class="form-group">
               <label for="guest" class="col-md-12 control-label">Total Guests : </label>
                <div class="col-sm-12 detail-total">                  
                 <input type="text" readonly disabled class="form-control" id="guest" name="total_guests">
                </div>
              </div>
              <div class="form-group">
               <label for="greeting" class="col-md-12 control-label">Greeting : </label>
                <div class="col-sm-12 detail-greet">                  
                 <input type="text" readonly disabled class="form-control" id="greeting" name="greeting"
                   value="<?php echo e($value->greeting); ?>">
                </div>
              </div>
              <div class="form-group">
               <label for="note" class="col-md-12 control-label">Note : </label>
                <div class="col-sm-12 detail-note">                  
                 <input type="text" readonly disabled class="form-control" id="note" name="note" value="<?php echo e($value->note); ?>">
                </div>
              </div>
             <div class="form-group">
              <label for="note" class="col-md-12 control-label">Total Payment </label>
               <div class="col-sm-12 detail-total_payment">                  
                <input type="text" readonly disabled class="form-control" id="total_payment" name="total_payment" value="<?php echo e($value->total_payment); ?>">
               </div>
             </div>
             <div class="form-group">
              <label for="note" class="col-md-12 control-label">List Asset : </label>
               <div class="col-sm-12 detail-list">                  
                <input type="text" readonly disabled class="form-control" id="list" name="list" value="<?php echo e($value->package->assets->implode('name_asset',', ')); ?>">
                </div>
            </div>
            <div class="box-footer">
            <center>
             <center><button class="btn btn-sm btn-success" class="close" data-dismiss="modal"><span aria-hidden="true">Back</span></button></center>
            </center>
             <br>
              </div>
            </form>
          </div>
        </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- <script src="js/jqBootstrapValidation.js"></script> -->
    <script type='text/javascript'>  
    function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
  </script>
  <script type="text/javascript">
  function detailOrder(dom) {
    var name_package = $(dom).data('name_package');
    var date_using = $(dom).data('date_using');
    var date_finish = $(dom).data('date_finish'); 
    var theme = $(dom).data('theme');
    var place = $(dom).data('place');
    var guest = $(dom).data('guest');
    var greeting = $(dom).data('greeting');
    var note = $(dom).data('note');
    var total_payment = $(dom).data('total_payment');
    var list = $(dom).data('list');
    $('#name_package').val(name_package)
    $('#date_using').val(date_using)
    $('#date_finish').val(date_finish) 
    $('#theme').val(theme)
    $('#place').val(place)
    $('#guest').val(guest)
    $('#greet').val(greeting)
    $('#note').val(note)
    $('#total_payment').val(total_payment)
    $('#list').val(list)
    $('#modal-lihat').modal('show')
  }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>