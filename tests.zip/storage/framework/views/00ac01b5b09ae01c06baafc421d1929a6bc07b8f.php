    <?php $__env->startSection('content'); ?>
    <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text">
          <!-- <div class="intro-lead-in">Welcome To Our Event Planner</div> -->
          <div class="intro-heading text-uppercase"></div>
          <!-- <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Tell Me More</a> -->
        </div>
      </div>
    </header> 

    <!-- Services -->
    <section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">

            <h4 class="section-heading text-uppercase">Precious Party Planner</h4>
            <center><div class="col-md-4">
             <img class="img-fluid" src="img/p.png" alt="">
            <h4 class="service-heading"></h4>
              precious party planner is a start up that provides services to prepare your event</p>
          </div></center>
          </div>
        </div>
         <div class="row">
          <div class="col-lg-12 text-center">
            <h5>Steps for Order</h5>
          </div>

        </div>
        <div class="row text-center">
          <div class="col-md-4">
           <span class="fa-stack fa-4x">
              <img class="img-fluid" src="img/pesan.png" alt="">
            </span>
            <h6 class="service-heading">Order Package</h6>
            <p class="text-muted">Order package which do you want</p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <img class="img-fluid" src="img/bayar.png" alt="">
            </span>
            <h6 class="service-heading">Payment Process</h6>
            <p class="text-muted">Doing payment process you can do it twice</p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <img class="img-fluid" src="img/yolo.png" alt="">
            </span>
            <h6 class="service-heading">Waiting</h6>
            <p class="text-muted">Just waiting, we will process it</p>
          </div>
        </div>
      </div>
    </section>

        <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Contact Us</h2>            
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
          </div>
        </div>
      </div>
    </section>

   
    <!-- Portfolio Modals -->

<?php $__env->stopSection(); ?>
 <!-- Footer -->

    <!-- Bootstrap core JavaScript -->
    

  </body>

</html>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>