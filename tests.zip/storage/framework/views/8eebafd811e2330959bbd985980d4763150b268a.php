    <?php $__env->startSection('content'); ?>

     <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Calendar Reservation</h2>
            <h3 class="section-subheading text-muted">We provide several package</h3>
          </div>
        </div>
        <p>
        <div class="row">          
          <div class="col-md-4 col-sm-6 portfolio-item">
                     
          </div>
        </div>
          
            
    </section>

    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Package</h2>
            <h3 class="section-subheading text-muted">We provide several package</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 text-center">
            <a class="btn btn-primary btn-md text-uppercase js-scroll-trigger" href="<?php echo e(url('/form_package')); ?>">Order Package</a>
          </div>
        </div>
        <p>
        <div class="row">
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  
                </div>
              </div>
              <img class="img-fluid" src="img/a.jpg" alt=""><p>
            </a>
            <div class="portfolio-caption">           
            </div>
          </div> <p>
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  
                </div>
              </div>
              <img class="img-fluid" src="img/c.jpg" alt=""></a><p>
            </a>
            <div class="portfolio-caption">
              </div>
          </div><p>
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                 
                </div>
              </div>
              <img class="img-fluid" src="img/d.jpg" alt=""></a><p>
            </a>
            <div class="portfolio-caption">
                          </div>
          </div><p>
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                </div>
              </div>

      </div>

              <div class="row">
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  
                </div>
              </div>
              <img class="img-fluid" src="img/a.jpg" alt=""><p>
            </a>
            <div class="portfolio-caption">
              
            </div>
          </div> <p>
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  
                </div>
              </div>
              <img class="img-fluid" src="img/c.jpg" alt=""></a><p>
            </a>
            <div class="portfolio-caption">
              
            </div>
          </div><p>
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                 
                </div>
              </div>
              <img class="img-fluid" src="img/d.jpg" alt=""></a><p>
            </a>
            <div class="portfolio-caption">
              
            </div>
          </div><p>
          <div class="col-md-4 col-sm-6 portfolio-item">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                </div>
              </div>
    </section>

<?php $__env->stopSection(); ?>
    <!-- Bootstrap core JavaScript -->
    </body>

</html>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>