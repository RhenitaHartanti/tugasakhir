<center><div>
<h4><b>Your Password </b></h4><br>
<b><?php echo e($password); ?></b>
You can login with this code and you can replace it after that <br>
Thankyou,<br>
Precious Party Planner
</div></center>