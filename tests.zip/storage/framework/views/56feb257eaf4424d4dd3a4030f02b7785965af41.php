<?php $__env->startSection('content'); ?>
 <br>
    <br>
<div class="container" style="background-image:img/wa.jpg">
 <div class="row justify-content-center">
  <div class="col-md-8">
   <div class="login">
    <img class="img-fluid" src="img/logo17.jpg" alt="">
     <div class="card-body">
      <form method="POST" action="<?php echo e(route('login')); ?>">
       <?php echo csrf_field(); ?>
        <center> Enter your username and password. Don't have account ? <a href="<?php echo e(url('/register')); ?>"> 
         <u>Register here</center></u></a><br>
         <div class="form-group row has-error">
           <label for="username" class="col-sm-4 col-form-label text-md-right">
             <?php echo e(__('Username')); ?></label>
             <div class="col-md-6">
               <input id="username" type="text" class="form-control" name="username"
                value="<?php echo e(old('username')); ?>"
                <?php if($errors->has('username')): ?> style="border-color:#DF0101" <?php endif; ?>>
                 <?php if($errors->has('username')): ?>
                  <span class="help-block" style="color:#DF0101">
                     <strong><?php echo e($errors->first('username')); ?></strong>
                  </span>
                  <?php endif; ?>
             </div>
          </div>
          <div class="form-group row">
            <label for="password" class="col-md-4 col-form-label text-md-right">
             <?php echo e(__('Password')); ?></label>
             <div class="col-md-6">
               <input id="password" type="password" class="form-control" name="password"
                <?php if($errors->has('password')): ?> style="border-color:#DF0101" <?php endif; ?>>
                <?php if($errors->has('password')): ?>
                 <span class="help-block" style="color:#DF0101">
                  <strong><?php echo e($errors->first('password')); ?></strong>
                 </span>
                <?php endif; ?>
             </div>
            </div>                    
            <div class="col-md-12">
             <div class="form-group row mb-0">
              <div class="col-md-8 offset-md-4">
               <button type="submit" class="btn btn-primary"><?php echo e(__('Login')); ?></button><br>
                 <a href="<?php echo e(url('/forgetPassword')); ?>"><u>Forget your password ?</a>                               
              </div>
             </div>
            </div>
          </form>
         </div>
        </div>
       </div>
    </div>
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>