<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<section class="content-header">
<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <center><h3>LIST CUSTOMERS</h3></center>
              <br>
            </div>
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th><center>Id Customer</center></th>
                    <th><center>Level</center></th>
                    <th><center>Name</center></th>
                    <th><center>Username</center></th>
                    <th><center>Email</center></th>
                    <th><center>No HP</center></th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pnjg = strlen($data->id);
                      if($pnjg==1){
                        $id = 'CST00'.$data->id;
                      }elseif($pnjg==2){
                        $id = 'CST0'.$data->id;
                      }else{
                        $id = 'CST'.$data->id;
                      }
                    ?>
                    <tr>                                  
                      <td><center><?php echo e($id); ?></center></td>
                      <td><center><?php echo e($data->level); ?></center></td>
                      <td><?php echo e($data->name); ?></td>
                      <td><?php echo e($data->username); ?></td>
                      <td><?php echo e($data->email); ?></td>
                      <td><?php echo e($data->nohp); ?></td>
                    </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>                           
              </table>
             </div>
          </div>
        </div>
      </div> 
 </section>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>