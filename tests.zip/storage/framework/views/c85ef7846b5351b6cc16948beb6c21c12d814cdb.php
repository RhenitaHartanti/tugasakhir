<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <section id="service">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="section-heading text-uppercase">Package Event</h2>
            <h3 class="section-subheading text-muted">This Package Include the Documentation (Photo and Video) </h3>
          </div>
        </div>
        <div class="row">
          <?php $__currentLoopData = $listpackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4">
          <img class="img-fluid" src="img/logo8.jpg" alt="">           
            <div class="package">
                <center>
                <h3 class="section-subheading text-muted" style="font-size: 20px">             
                  <?php echo e($data->name_package); ?><br><br>
                  Rp. <?php echo e(number_format($data->price,2,',','.')); ?><br>  
                </h3>
                <h3 class="section-subheading text-muted" style="font-size: 15px">    
                  <b>for <?php echo e($data->kuota); ?> people</b><br>                   
                </h3><hr>
                <h3 class="section-subheading text-muted" style="font-size: 15px">
                  Details Items :<br><br>
                  <?php $__currentLoopData = $data->assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($val->name_asset); ?><br><br>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h3>               
                  <?php if(!\Auth::check()): ?>
                    <a class="btn btn-primary btn-md text-uppercase js-scroll-trigger" href="<?php echo e(url('/login')); ?>" style="background:#B8860B">Order Package</a>
                  <?php else: ?>
                    <a class="btn btn-primary btn-md text-uppercase js-scroll-trigger" href="<?php echo e(url('/landingpage_formpackage',$data->id)); ?>" style="background:#B8860B; color:#ffffff;">Order Package</a>
                  <?php endif; ?>                  
                </center>
                <br>
            </div> 

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <img class="img-fluid" src="img/logo8.jpg" alt="">           
            <div class="package">
                <center><br>
                <h3 class="section-subheading text-muted" style="font-size: 30px">             
                  Custom Package<br><br>
                </h3>
               <h3 class="section-subheading text-muted" style="font-size: 20px">             
                  Start from Rp 1.000.000,00<br><br>
                </h3>
                <h3 class="section-subheading text-muted" style="font-size: 15px">    
                  <b>custom your package order based on your need</b><br>                   
                </h3>               
                  <?php if(!\Auth::check()): ?>
                    <a class="btn btn-primary btn-md text-uppercase js-scroll-trigger" href="<?php echo e(url('/login')); ?>">Order Package</a>
                  <?php else: ?>
                    <a class="btn btn-primary btn-md text-uppercase js-scroll-trigger" href="<?php echo e(url('/landingpage_formpackagecustom')); ?>" style="background:#B8860B">Order Package</a>
                  <?php endif; ?>                  
                </center>
                <br>
            </div> 
                      
        </div>

      </div>
              <br>   
    </section>
<?php $__env->stopSection(); ?>
  </body>
</html>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>